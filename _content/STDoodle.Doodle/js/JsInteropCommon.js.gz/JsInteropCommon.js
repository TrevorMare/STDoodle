export function ClickElement(element) {
    if (element !== undefined && element != null) {
        element.click();
    }
}
