
export function ClickElement(element: HTMLElement): void {
  if (element !== undefined && element != null) { 
    element.click();
  }
}